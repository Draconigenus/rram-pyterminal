
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

####################

def ld_to_dl(ld):
    dl = {}

    for i, d in enumerate(ld):
        for key in d.keys():
            value = d[key]
            if i == 0:
                dl[key] = [value]
            else:
                dl[key].append(value)

    return dl

####################

results = np.load('results_10_25_50.npy', allow_pickle=True).item()

data = { 'step_size': [], 'step': [], 'addr': [], 'R': [] }
for key in results.keys():
    (step_size, step, row) = key
    data['step_size'].append(step_size)
    data['step']     .append(step)
    data['addr']     .append(row)
    data['R']        .append(results[key])

df = pd.DataFrame.from_dict(data)

####################

table = df.to_numpy()
np.savetxt(fname='results.csv', X=table, fmt='%f', delimiter=',', header='step_size,step,addr,resistance', comments='')

####################

step_sizes = np.unique(df.step_size)
for step_size in step_sizes:
    ###############################################################
    xs = []
    ys = []
    ###############################################################
    df_step_size = df[ df.step_size == step_size ]
    steps = np.unique(df_step_size.step)
    for step in steps:
        df_step = df_step_size[ df_step_size.step == step ]
        R = np.mean(df_step.R)
        xs.append(2000 + step * step_size)
        ys.append(R)
    ###############################################################
    plt.plot(xs, ys, label=str(step_size))

# plt.show()
plt.legend()
plt.xlabel('Write Voltage')
plt.ylabel('Resistance (Ohms)')
plt.savefig('results.png', dpi=500)

####################






