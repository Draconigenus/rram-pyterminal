
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

####################

results = np.load('results_10_25_50.npy', allow_pickle=True).item()

for step in range(1, 80 + 1):
    for addr in range(32):
        key1 = (10, step    , addr)
        key2 = (10, step - 1, addr)
        results[key1] = max(results[key1], results[key2])

for step in range(1, 32 + 1):
    for addr in range(32):
        key1 = (25, step    , addr)
        key2 = (25, step - 1, addr)
        results[key1] = max(results[key1], results[key2])

for step in range(1, 16 + 1):
    for addr in range(32):
        key1 = (50, step    , addr)
        key2 = (50, step - 1, addr)
        results[key1] = max(results[key1], results[key2])

####################

data = { 'step_size': [], 'step': [], 'addr': [], 'R': [] }
for key in results.keys():
    (step_size, step, row) = key
    data['step_size'].append(step_size)
    data['step']     .append(step)
    data['addr']     .append(row)
    data['R']        .append(results[key])

df = pd.DataFrame.from_dict(data)

####################

table = df.to_numpy()
table[:, 1] = table[:, 0] * table[:, 1] + 2000
np.savetxt(fname='results.csv', X=table, fmt='%f', delimiter=',', header='step_size,step,addr,resistance', comments='')

####################

step_sizes = np.unique(df.step_size)
for step_size in step_sizes:
    ###############################################################
    xs = []
    ys = []
    ###############################################################
    df_step_size = df[ df.step_size == step_size ]
    steps = np.unique(df_step_size.step)
    for step in steps:
        df_step = df_step_size[ df_step_size.step == step ]
        R = np.mean(df_step.R)
        xs.append(2000 + step * step_size)
        ys.append(R)
    ###############################################################
    plt.scatter(xs, ys, label=str(step_size))

# plt.show()
plt.legend()
plt.xlabel('Write Voltage')
plt.ylabel('Resistance (Ohms)')
plt.savefig('results.png', dpi=500)

####################






