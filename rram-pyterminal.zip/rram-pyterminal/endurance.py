
import random
import time
from ctypes import c_int8
import numpy as np

import Board.DAC
from Lib import RRAM
from resistance import resistance, references

##########################################################

def check(addr, refs, VTGT):
    #########################################
    RRAM.set(level='cell', number=str(addr), verbal=False)
    # lrs = resistance(addr, refs, VTGT)
    rd = int( RRAM.read_lane(address=str(addr), data='0x001', verbal=False), 16)
    #########################################
    RRAM.reset(level='cell', number=str(addr), verbal=False)
    # hrs = resistance(addr, refs, VTGT)
    rd = int( RRAM.read_lane(address=str(addr), data='0x001', verbal=False), 16)
    #########################################
    saf = lrs > (hrs + 1000)
    #########################################
    return saf, lrs, hrs

##########################################################

def endurance(module, addr):

    if module == '': module = 0
    else:            module = int(module)

    if addr == '': addr = 200
    else:          addr = int(addr)

    RRAM.conf_set(AVDD_WR=str(2200), AVDD_WL=str(1200), cycle=str(16), times=str(10), verbal=False)
    RRAM.conf_reset(AVDD_WR=str(2800), AVDD_WL=str(2800), cycle=str(100), times=str(10), verbal=False)

    VTGT = 200
    Board.DAC.set_source(value=str(VTGT), target='VTGT_BL', verbal=False)    
    refs = references(module=module, col=addr, VTGT=VTGT)

    total = int(1e6)
    batch_size = int(1e2)
    batch_num = total // batch_size
    status = np.zeros(shape=(batch_num, 256, 3))

    start = time.time()
    for batch in range(batch_num):
        for _ in range(batch_size):
            RRAM.set(level='col', number=str(addr), verbal=False)
            RRAM.reset(level='col', number=str(addr), verbal=False)

        for row in range(256):
            address = row * 256 + addr
            status[batch][row] = check(addr=address, refs=refs, VTGT=VTGT)
            print (status[batch][row])

        duration = time.time() - start
        rate = (batch * batch_size + batch_size) / duration
        stuck = np.sum(status[batch] > 0)
        print ('switch / sec: %f | stuck devices: %d/%d' % (rate, stuck, 256))

        results = {'batch': batch, 'status': status, 'resistance': Resistance}
        np.save('endurance', results)

##########################################################

